import os
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
ENV_PATH = BASE_DIR / '.env'
if ENV_PATH.exists():
    load_dotenv(ENV_PATH, override=True, encoding='utf-8-sig')
else:
    load_dotenv(override=True, encoding='utf-8-sig')


def _clean(name: str, default: str = '') -> str:
    value = os.getenv(name, default)
    if value is None:
        value = default
    return str(value).replace('\ufeff', '').replace('\xa0', ' ').strip()


ASSETS_DIR = BASE_DIR / 'assets'
TILE_PATHS = [ASSETS_DIR / f'{i}.png' for i in range(1, 5)]

DB = {
    'host': _clean('DB_HOST', 'localhost'),
    'port': int(_clean('DB_PORT', '5432')),
    'dbname': _clean('DB_NAME', 'production_is'),
    'user': _clean('DB_USER', 'postgres'),
    'password': _clean('DB_PASSWORD', '12345'),
}

ADMIN_ROLE = 'Администратор'
USER_ROLE = 'Пользователь'
APP_TITLE = 'Информационная система производства'
