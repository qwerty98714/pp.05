import hashlib
import psycopg2
from psycopg2 import Error
from config import DB, ADMIN_ROLE, USER_ROLE, BASE_DIR


def hash_password(value: str) -> str:
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


def connect():
    try:
        conn = psycopg2.connect(**DB)
        conn.autocommit = True
        return conn
    except UnicodeDecodeError:
        raise RuntimeError(
            'Ошибка чтения параметров подключения к БД. '
            'Проверьте файл .env рядом с app.py и сохраните его в UTF-8.'
        )
    except Error as e:
        raise RuntimeError(f'Ошибка подключения к PostgreSQL: {e}')


def one(sql, params=()):
    with connect() as conn, conn.cursor() as cur:
        cur.execute(sql, params)
        return cur.fetchone()


def all_rows(sql, params=()):
    with connect() as conn, conn.cursor() as cur:
        cur.execute(sql, params)
        return cur.fetchall()


def run(sql, params=()):
    with connect() as conn, conn.cursor() as cur:
        cur.execute(sql, params)


def ensure_schema():
    script = (BASE_DIR / 'sql' / 'init_users_roles.sql').read_text(encoding='utf-8')
    with connect() as conn, conn.cursor() as cur:
        cur.execute(script)


def ensure_demo_data():
    ensure_schema()
    run('INSERT INTO roles(name) VALUES (%s) ON CONFLICT (name) DO NOTHING', (ADMIN_ROLE,))
    run('INSERT INTO roles(name) VALUES (%s) ON CONFLICT (name) DO NOTHING', (USER_ROLE,))
    admin_role_id = one('SELECT id FROM roles WHERE name=%s', (ADMIN_ROLE,))[0]
    user_role_id = one('SELECT id FROM roles WHERE name=%s', (USER_ROLE,))[0]

    for login, password, role_id in [
        ('admin', 'admin123', admin_role_id),
        ('user1', 'user123', user_role_id),
    ]:
        run(
            '''
            INSERT INTO users(login, password_hash, role_id, is_blocked, failed_attempts)
            VALUES (%s, %s, %s, FALSE, 0)
            ON CONFLICT (login) DO UPDATE SET
                password_hash = EXCLUDED.password_hash,
                role_id = EXCLUDED.role_id,
                is_blocked = FALSE,
                failed_attempts = 0
            ''',
            (login, hash_password(password), role_id),
        )


def roles():
    return all_rows('SELECT id, name FROM roles ORDER BY id')


def users():
    return all_rows(
        '''
        SELECT u.id, u.login, r.name,
               CASE WHEN u.is_blocked THEN 'Да' ELSE 'Нет' END,
               u.failed_attempts, u.is_blocked
        FROM users u
        JOIN roles r ON r.id = u.role_id
        ORDER BY u.id
        '''
    )


def get_user(login):
    row = one(
        '''
        SELECT u.id, u.login, u.password_hash, u.failed_attempts, u.is_blocked, r.id, r.name
        FROM users u
        JOIN roles r ON r.id = u.role_id
        WHERE u.login = %s
        ''',
        (login,),
    )
    if not row:
        return None
    return {
        'id': row[0],
        'login': row[1],
        'password_hash': row[2],
        'failed_attempts': row[3],
        'is_blocked': row[4],
        'role_id': row[5],
        'role_name': row[6],
        'is_admin': row[6] == ADMIN_ROLE,
    }


def bump_fail(user_id):
    row = one(
        '''
        UPDATE users
           SET failed_attempts = failed_attempts + 1,
               is_blocked = CASE WHEN failed_attempts + 1 >= 3 THEN TRUE ELSE is_blocked END
         WHERE id = %s
     RETURNING failed_attempts, is_blocked
        ''',
        (user_id,),
    )
    return row[0], row[1]


def reset_fails(user_id):
    run('UPDATE users SET failed_attempts = 0 WHERE id = %s', (user_id,))


def check_captcha(login):
    user = get_user(login)
    if not user:
        return None, 'Вы ввели неверный логин или пароль. Пожалуйста, проверьте ещё раз введенные данные.'
    if user['is_blocked']:
        return None, 'Вы заблокированы. Обратитесь к администратору.'
    return user, None


def captcha_failed(user):
    attempts, blocked = bump_fail(user['id'])
    if blocked:
        return 'Вы заблокированы. Обратитесь к администратору.'
    return f'Пазл собран неверно. Попытка {attempts}/3.'


def authenticate(login, password):
    user = get_user(login)
    if not user:
        return None, 'Вы ввели неверный логин или пароль. Пожалуйста, проверьте ещё раз введенные данные.'
    if user['is_blocked']:
        return None, 'Вы заблокированы. Обратитесь к администратору.'
    if hash_password(password) != user['password_hash']:
        attempts, blocked = bump_fail(user['id'])
        if blocked:
            return None, 'Вы заблокированы. Обратитесь к администратору.'
        return None, f'Вы ввели неверный логин или пароль. Попытка {attempts}/3.'
    reset_fails(user['id'])
    return get_user(login), None


def add_user(login, password, role_id, is_blocked):
    run(
        '''
        INSERT INTO users(login, password_hash, role_id, is_blocked, failed_attempts)
        VALUES (%s, %s, %s, %s, 0)
        ''',
        (login, hash_password(password), role_id, is_blocked),
    )


def update_user(user_id, login, password, role_id, is_blocked):
    if password:
        run(
            'UPDATE users SET login=%s, password_hash=%s, role_id=%s, is_blocked=%s WHERE id=%s',
            (login, hash_password(password), role_id, is_blocked, user_id),
        )
    else:
        run(
            'UPDATE users SET login=%s, role_id=%s, is_blocked=%s WHERE id=%s',
            (login, role_id, is_blocked, user_id),
        )


def unblock_user(user_id):
    run('UPDATE users SET is_blocked = FALSE, failed_attempts = 0 WHERE id = %s', (user_id,))


def startup_error():
    try:
        ensure_demo_data()
        return None
    except Exception as e:
        return str(e)
