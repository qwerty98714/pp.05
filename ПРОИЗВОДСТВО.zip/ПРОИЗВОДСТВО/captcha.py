import random
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
from config import TILE_PATHS


class CaptchaDialog(tk.Toplevel):
    def __init__(self, parent, on_success, on_fail):
        super().__init__(parent)
        self.on_success, self.on_fail = on_success, on_fail
        self.title('Капча-пазл')
        self.resizable(False, False)
        self.selected = None
        self.order = list(range(4))
        random.shuffle(self.order)
        self.images = [ImageTk.PhotoImage(Image.open(path).resize((130, 130))) for path in TILE_PATHS]
        tk.Label(self, text='Соберите изображение из 4 частей', font=('Arial', 11, 'bold')).pack(pady=8)
        self.frame = tk.Frame(self)
        self.frame.pack(padx=8, pady=4)
        tk.Button(self, text='Проверить', command=self.check).pack(pady=10)
        self.draw()
        self.grab_set()

    def draw(self):
        for widget in self.frame.winfo_children():
            widget.destroy()
        self.buttons = []
        for i, idx in enumerate(self.order):
            btn = tk.Button(self.frame, image=self.images[idx], command=lambda x=i: self.swap(x))
            btn.grid(row=i // 2, column=i % 2, padx=4, pady=4)
            self.buttons.append(btn)

    def swap(self, index):
        if self.selected is None:
            self.selected = index
            self.buttons[index].config(relief='sunken', bd=4)
            return
        self.order[self.selected], self.order[index] = self.order[index], self.order[self.selected]
        self.selected = None
        self.draw()

    def check(self):
        self.destroy()
        if self.order == [0, 1, 2, 3]:
            self.on_success()
        else:
            self.on_fail()
