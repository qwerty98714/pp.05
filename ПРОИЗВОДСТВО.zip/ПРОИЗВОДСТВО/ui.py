import tkinter as tk
from tkinter import ttk, messagebox
import psycopg2
from captcha import CaptchaDialog
from core import startup_error, check_captcha, captcha_failed, authenticate, roles, users, add_user, update_user, unblock_user
from config import APP_TITLE


class UserDialog(tk.Toplevel):
    def __init__(self, parent, role_rows, on_save, row=None):
        super().__init__(parent)
        self.title('Пользователь')
        self.resizable(False, False)
        self.role_rows, self.on_save, self.row = role_rows, on_save, row
        self.login = tk.StringVar(value=row[1] if row else '')
        self.password = tk.StringVar()
        self.role = tk.StringVar(value=row[2] if row else role_rows[0][1])
        self.blocked = tk.BooleanVar(value=(row[5] if row else False))
        fields = [('Логин', tk.Entry(self, textvariable=self.login, width=30)),
                  ('Пароль', tk.Entry(self, textvariable=self.password, width=30, show='*')),
                  ('Роль', ttk.Combobox(self, textvariable=self.role, values=[x[1] for x in role_rows], state='readonly', width=27))]
        for i, (label, widget) in enumerate(fields):
            tk.Label(self, text=label).grid(row=i, column=0, sticky='w', padx=10, pady=6)
            widget.grid(row=i, column=1, padx=10, pady=6)
        tk.Checkbutton(self, text='Заблокирован', variable=self.blocked).grid(row=3, column=1, sticky='w', padx=10)
        tk.Button(self, text='Сохранить', command=self.save).grid(row=4, column=0, columnspan=2, pady=10)
        self.grab_set()

    def save(self):
        if not self.login.get().strip():
            return messagebox.showerror('Ошибка', 'Логин обязателен.')
        if not self.row and not self.password.get().strip():
            return messagebox.showerror('Ошибка', 'Пароль обязателен.')
        role_id = next(role_id for role_id, name in self.role_rows if name == self.role.get())
        self.on_save(self.login.get().strip(), self.password.get().strip(), role_id, self.blocked.get())
        self.destroy()


class BaseWindow(tk.Tk):
    def logout(self):
        self.destroy()
        LoginWindow().mainloop()


class UserWindow(BaseWindow):
    def __init__(self, user):
        super().__init__()
        self.title('Рабочее место пользователя')
        self.geometry('430x220')
        tk.Label(self, text='Вы успешно авторизовались', font=('Arial', 13, 'bold')).pack(pady=18)
        tk.Label(self, text=f'Логин: {user["login"]}').pack(pady=6)
        tk.Label(self, text=f'Роль: {user["role_name"]}').pack(pady=6)
        ttk.Button(self, text='Выход из учетной записи', command=self.logout).pack(pady=20)


class AdminWindow(BaseWindow):
    def __init__(self, user):
        super().__init__()
        self.title('Рабочее место администратора')
        self.geometry('860x500')
        self.minsize(860, 500)
        self.role_rows = roles()
        tk.Label(self, text=f'Вы вошли как: {user["login"]} ({user["role_name"]})', font=('Arial', 12, 'bold')).pack(pady=10)
        self.table = ttk.Treeview(self, columns=('id', 'login', 'role', 'blocked', 'fails'), show='headings')
        for col, text, width in [('id', 'ID', 70), ('login', 'Логин', 240), ('role', 'Роль', 180), ('blocked', 'Заблокирован', 130), ('fails', 'Ошибки', 90)]:
            self.table.heading(col, text=text)
            self.table.column(col, width=width, anchor='center')
        self.table.pack(fill='both', expand=True, padx=10, pady=10)
        row = ttk.Frame(self); row.pack(pady=5)
        for text, cmd in [('Добавить', self.add_user), ('Редактировать', self.edit_user), ('Снять блокировку', self.unblock), ('Обновить', self.refresh), ('Выход из учетной записи', self.logout)]:
            ttk.Button(row, text=text, command=cmd).pack(side='left', padx=5)
        self.refresh()

    def refresh(self):
        self.role_rows = roles()
        self.table.delete(*self.table.get_children())
        for row in users():
            self.table.insert('', 'end', values=row[:5], tags=(str(row[5]),))

    def current(self):
        item = self.table.selection()
        if not item:
            messagebox.showwarning('Ошибка', 'Выберите пользователя.')
            return None
        view = self.table.item(item[0], 'values')
        hidden_blocked = self.table.item(item[0], 'tags')[0] == 'True'
        return [int(view[0]), view[1], view[2], view[3], int(view[4]), hidden_blocked]

    def add_user(self):
        def save(login, password, role_id, is_blocked):
            try:
                add_user(login, password, role_id, is_blocked)
                self.refresh()
            except psycopg2.Error as e:
                messagebox.showerror('Ошибка', str(e).splitlines()[0])
        UserDialog(self, self.role_rows, save)

    def edit_user(self):
        row = self.current()
        if not row:
            return
        def save(login, password, role_id, is_blocked):
            try:
                update_user(row[0], login, password, role_id, is_blocked)
                self.refresh()
            except psycopg2.Error as e:
                messagebox.showerror('Ошибка', str(e).splitlines()[0])
        UserDialog(self, self.role_rows, save, row)

    def unblock(self):
        row = self.current()
        if not row:
            return
        unblock_user(row[0])
        messagebox.showinfo('Готово', 'Пользователь разблокирован.')
        self.refresh()


class LoginWindow(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry('340x230')
        self.resizable(False, False)
        self.pending = None
        error = startup_error()
        if error:
            messagebox.showerror('Ошибка', error)
        tk.Label(self, text='Авторизация', font=('Arial', 15, 'bold')).pack(pady=12)
        tk.Label(self, text='Логин').pack()
        self.login = tk.Entry(self, width=30)
        self.login.pack(pady=4)
        tk.Label(self, text='Пароль').pack()
        self.password = tk.Entry(self, width=30, show='*')
        self.password.pack(pady=4)
        ttk.Button(self, text='Войти', command=self.open_captcha).pack(pady=14)

    def open_captcha(self):
        login, password = self.login.get().strip(), self.password.get().strip()
        if not login or not password:
            return messagebox.showerror('Ошибка', 'Поля логин и пароль обязательны для заполнения.')
        user, error = check_captcha(login)
        if error:
            return messagebox.showerror('Ошибка', error)
        self.pending = (login, password, user)
        CaptchaDialog(self, self.after_captcha_ok, self.after_captcha_fail)

    def after_captcha_fail(self):
        _, _, user = self.pending
        messagebox.showerror('Ошибка', captcha_failed(user))

    def after_captcha_ok(self):
        user, error = authenticate(self.pending[0], self.pending[1])
        if error:
            return messagebox.showerror('Ошибка', error)
        messagebox.showinfo('Успех', 'Вы успешно авторизовались')
        self.destroy()
        (AdminWindow if user['is_admin'] else UserWindow)(user).mainloop()
